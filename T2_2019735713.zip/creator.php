<?php
    include_once("header.php")
?>
<div class="middleWrapper">
    <section class="creator-intro">

        <h2>Work in Progress</h2>

        <span>Creador: <a href="https://github.com/Joacaldo7965"><b>https://github.com/Joacaldo7965</b></a></span> 
    </section>
</div>


<?php
    include_once("footer.php")
?>