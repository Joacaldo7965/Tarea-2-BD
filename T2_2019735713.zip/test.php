<div id="LogoDivision">
        <div id="LogoLeftDivision">
            <!-- <p>First Division</p> -->
            <img id="Logo" src="res/imagenes/Logo.png">
        </div>
        <div id="LogoRightDivision">
            <!-- <p>Second Division</p> -->
            <h1 id="LogoTitle">USMwer</h1>
        </div>
    </div>
    <nav id="navbar">
        <a class="navbarElem" href="index.php"><b>Inicio</b></a> |
        <a class="navbarElem" href="feed.php"><b>Feed</b></a> |
        <a class="navbarElem" href="creator.php"><b>Creador</b></a> |
    </nav> 