Nombre : Joaquin Calderon Donoso
Rol    : 201973571-3


Instrucciones de uso:
	- Hostear los archivos junto a un servidor Apache y MySQL
	- Se entra a la pagina por "index.php"